
import { useEffect, useMemo, useState } from "react";
import "./index.css";

const initialTransactions = [
  {
    id: 1,
    title: "Monthly Salary",
    amount: 50000,
    type: "income",
    category: "Salary",
    date: "2026-10-01",
  },
  {
    id: 2,
    title: "Grocery Shopping",
    amount: 4500,
    type: "expense",
    category: "Food",
    date: "2026-10-03",
  },
  {
    id: 3,
    title: "Internet Bill",
    amount: 2000,
    type: "expense",
    category: "Bills",
    date: "2026-10-05",
  },
];

const currency = (amount) =>
  new Intl.NumberFormat("en-PK", {
    style: "currency",
    currency: "PKR",
    maximumFractionDigits: 0,
  }).format(amount);

function App() {
  const [transactions, setTransactions] = useState(() => {
    try {
      const saved = localStorage.getItem("expense-tracker-transactions");
      return saved === null ? initialTransactions : JSON.parse(saved);
    } catch {
      return initialTransactions;
    }
  });

  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");
  const [type, setType] = useState("expense");
  const [category, setCategory] = useState("Food");
  const [date, setDate] = useState(
    new Date().toLocaleDateString("en-CA")
  );
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [formError, setFormError] = useState("");
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    localStorage.setItem(
      "expense-tracker-transactions",
      JSON.stringify(transactions)
    );
  }, [transactions]);

  const totals = useMemo(() => {
    const income = transactions
      .filter((item) => item.type === "income")
      .reduce((sum, item) => sum + item.amount, 0);

    const expenses = transactions
      .filter((item) => item.type === "expense")
      .reduce((sum, item) => sum + item.amount, 0);

    return {
      income,
      expenses,
      balance: income - expenses,
    };
  }, [transactions]);

  const filteredTransactions = useMemo(() => {
    return transactions
      .filter((item) => filter === "all" || item.type === filter)
      .filter((item) =>
        `${item.title} ${item.category}`
          .toLowerCase()
          .includes(search.toLowerCase())
      )
      .sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id);
  }, [transactions, filter, search]);

  function handleSubmit(event) {
    event.preventDefault();
    setFormError("");

    const cleanTitle = title.trim();
    const numericAmount = Number(amount);

    if (!cleanTitle) {
      setFormError("Please enter a transaction title.");
      return;
    }

    if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
      setFormError("Please enter an amount greater than zero.");
      return;
    }

    if (!date) {
      setFormError("Please select a transaction date.");
      return;
    }

    const newTransaction = {
      id: Date.now(),
      title: cleanTitle,
      amount: numericAmount,
      type,
      category,
      date,
    };

    setTransactions((previous) => [newTransaction, ...previous]);
    setTitle("");
    setAmount("");
    setType("expense");
    setCategory("Food");
    setDate(new Date().toLocaleDateString("en-CA"));
    setShowForm(false);
  }

  function deleteTransaction(id) {
    const confirmed = window.confirm(
      "Are you sure you want to delete this transaction?"
    );

    if (confirmed) {
      setTransactions((previous) =>
        previous.filter((item) => item.id !== id)
      );
    }
  }

  return (
    <main className="dashboard">
      <aside className="sidebar">
        <a href="#" className="brand">
          <span className="brand-icon">◈</span>
          <span>Finora</span>
        </a>

        <p className="nav-label">WORKSPACE</p>
        <a className="nav-link active" href="#overview">
          <span>▦</span> Overview
        </a>
        <a className="nav-link" href="#transactions">
          <span>↔</span> Transactions
        </a>
        <a className="nav-link" href="#summary">
          <span>◷</span> Financial summary
        </a>

        <div className="sidebar-bottom">
          <div className="profile-avatar">N</div>
          <div>
            <strong>My Finance</strong>
            <p>Personal account</p>
          </div>
        </div>
      </aside>

      <section className="main-content" id="overview">
        <header className="page-header">
          <div>
            <p className="overline">YOUR MONEY, ORGANIZED</p>
            <h1>Financial Overview</h1>
            <p className="muted">
              Track your money and make every rupee count.
            </p>
          </div>
          <button
            className="primary-button"
            onClick={() => {
              setFormError("");
              setShowForm((value) => !value);
            }}
          >
            <span>＋</span> Add transaction
          </button>
        </header>

        <section className="stats-grid" id="summary">
          <article className="stat-card balance-card">
            <div className="stat-top">
              <span>Total balance</span>
              <span className="stat-icon">◈</span>
            </div>
            <h2>{currency(totals.balance)}</h2>
            <p className="stat-caption">Income minus expenses</p>
          </article>

          <article className="stat-card">
            <div className="stat-top">
              <span>Total income</span>
              <span className="stat-icon income-icon">↗</span>
            </div>
            <h2>{currency(totals.income)}</h2>
            <p className="stat-caption">Money received</p>
          </article>

          <article className="stat-card">
            <div className="stat-top">
              <span>Total expenses</span>
              <span className="stat-icon expense-icon">↘</span>
            </div>
            <h2>{currency(totals.expenses)}</h2>
            <p className="stat-caption">Money spent</p>
          </article>
        </section>

        {showForm && (
          <section className="form-card">
            <div className="section-heading">
              <div>
                <p className="overline">NEW ENTRY</p>
                <h2>Add a transaction</h2>
              </div>
              <button
                className="close-button"
                onClick={() => setShowForm(false)}
                aria-label="Close form"
              >
                ×
              </button>
            </div>

            <form onSubmit={handleSubmit}>
              <div className="type-switch">
                <button
                  type="button"
                  className={type === "expense" ? "selected expense-selected" : ""}
                  onClick={() => {
                    setType("expense");
                    setCategory("Food");
                  }}
                >
                  ↘ Expense
                </button>
                <button
                  type="button"
                  className={type === "income" ? "selected income-selected" : ""}
                  onClick={() => {
                    setType("income");
                    setCategory("Salary");
                  }}
                >
                  ↗ Income
                </button>
              </div>

              <div className="form-grid">
                <label>
                  Transaction title
                  <input
                    value={title}
                    onChange={(event) => setTitle(event.target.value)}
                    placeholder="e.g. Grocery shopping"
                    maxLength={80}
                  />
                </label>

                <label>
                  Amount (PKR)
                  <input
                    type="number"
                    min="0.01"
                    step="0.01"
                    value={amount}
                    onChange={(event) => setAmount(event.target.value)}
                    placeholder="e.g. 2500"
                  />
                </label>

                <label>
                  Category
                  <select
                    value={category}
                    onChange={(event) => setCategory(event.target.value)}
                  >
                    {(type === "income"
                      ? ["Salary", "Freelance", "Business", "Gift", "Other"]
                      : ["Food", "Transport", "Bills", "Shopping", "Health", "Education", "Other"]
                    ).map((item) => (
                      <option key={item} value={item}>{item}</option>
                    ))}
                  </select>
                </label>

                <label>
                  Date
                  <input
                    type="date"
                    value={date}
                    onChange={(event) => setDate(event.target.value)}
                  />
                </label>
              </div>

              {formError && <p className="form-error" role="alert">{formError}</p>}

              <button type="submit" className="primary-button submit-button">
                Save transaction
              </button>
            </form>
          </section>
        )}

        <section className="transactions-card" id="transactions">
          <div className="transactions-heading">
            <div>
              <p className="overline">YOUR ACTIVITY</p>
              <h2>Recent transactions</h2>
              <p className="muted">
                {transactions.length} transaction{transactions.length === 1 ? "" : "s"} in total
              </p>
            </div>
            <div className="transaction-controls">
              <input
                className="search-input"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search..."
                aria-label="Search transactions"
              />
              <select
                className="filter-select"
                value={filter}
                onChange={(event) => setFilter(event.target.value)}
                aria-label="Filter transactions"
              >
                <option value="all">All types</option>
                <option value="income">Income</option>
                <option value="expense">Expenses</option>
              </select>
            </div>
          </div>

          <div className="transaction-list">
            {filteredTransactions.length === 0 && (
              <div className="empty-state">
                <span>◷</span>
                <h3>No transactions found</h3>
                <p>Try another search or add a new transaction.</p>
              </div>
            )}

            {filteredTransactions.map((item) => (
              <article className="transaction-row" key={item.id}>
                <div className={`transaction-symbol ${item.type}`}>
                  {item.type === "income" ? "↗" : "↘"}
                </div>

                <div className="transaction-info">
                  <strong>{item.title}</strong>
                  <p>{item.category} · {formatDate(item.date)}</p>
                </div>

                <strong className={`transaction-amount ${item.type}`}>
                  {item.type === "income" ? "+" : "−"}{currency(item.amount)}
                </strong>

                <button
                  className="delete-button"
                  onClick={() => deleteTransaction(item.id)}
                  aria-label={`Delete ${item.title}`}
                  title="Delete transaction"
                >
                  ×
                </button>
              </article>
            ))}
          </div>
        </section>

        <footer className="page-footer">
          <span>Finora · Personal finance tracker</span>
          <span>Your data is saved in this browser.</span>
        </footer>
      </section>
    </main>
  );
}

function formatDate(dateString) {
  if (!dateString) return "";
  const date = new Date(`${dateString}T12:00:00`);
  return date.toLocaleDateString("en-PK", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export default App;
